# api-rest-php
Exemplo de CRUD utilizando arquitetura RESTful, feito com php.

  Baseado no projeto de Bruno Alencar https://github.com/BrunoAlencar/api-rest-php