<?php
	
	define('DB_NAME', 'agencia_noticia');
	define('DB_HOST', 'localhost');
	define('DB_PASS', '');
	define('DB_USER', 'root');

?>

